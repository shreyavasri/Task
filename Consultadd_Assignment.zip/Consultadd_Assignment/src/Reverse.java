import java.util.Scanner;

/*Write a JAVA program that reverse the words of a sentence.
i. For eg, => �Be Happy and Stay Motivated� => �eB yppah dna yatS
detavitoM
*/
public class Reverse {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		String word = scan.nextLine();
		System.out.println(new StringBuilder(word).reverse());
		scan.close();
	}

}
