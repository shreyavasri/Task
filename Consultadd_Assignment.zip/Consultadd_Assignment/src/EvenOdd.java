import java.util.Scanner;

/*
 * Write a JAVA program that takes out the even from the odds and odd from
the list of even numbers,
For eg, => {23,25,75,87,47,1,91,51,2} //Output for this case =>2
=> {22,44,64,76,98,12,43,54,90} // Output for this case =>43.

 */
public class EvenOdd {

	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);
		int[] array = new int[10];
		int count = 0;
		
		
		for(int i = 0; i<10;i++) {
			System.out.println("Enter elements to the array");
			array[i] = scan.nextInt();
		}
		System.out.println("Even elements are : ");
		for(int i = 0; i<10;i++) {
			if(array[i]%2 == 0) {
				System.out.println(array[i]);
				count++;
			}
			
			
		}
	System.out.println("Total even numbers : : "+count);
	scan.close();
	}

}
