package ClassAssignment;

public class MssqlConnector extends Connector {


	@Override
	public void openconnection() {
		System.out.println("Abstract implementaion Mssql connector");
	}
	
	public void displayMssql() {
		System.out.println("Mssql");
	}

}
