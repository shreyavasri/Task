package ClassAssignment;

public class OracleConnector extends Connector {
	
	@Override
	public void openconnection() {
		System.out.println("Abstract implementaion Oracle connector");
	}
	
	public void displayConnector() {
		System.out.println("Oracle");
	}
	
	
}
