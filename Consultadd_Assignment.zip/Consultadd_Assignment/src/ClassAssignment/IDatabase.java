package ClassAssignment;

public interface IDatabase {

	public void connection();
    public void openDB();
    public void closeDB();
    
}
