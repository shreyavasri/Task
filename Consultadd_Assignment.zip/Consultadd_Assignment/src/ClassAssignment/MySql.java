package ClassAssignment;

public class MySql extends AbDatabase {

	@Override
	public void connection() {
		System.out.println("This is connection method of MySql Class");
	}

	@Override
	public void openDB() {
		// TODO Auto-generated method stub
		System.out.println("This is Open DB method of MySql Class");

	}

	@Override
	public void closeDB() {
		// TODO Auto-generated method stub
		System.out.println("This is Close DB method of MySql Class");

	}
	public void dbName() {
		System.out.println( "MySql");
	}
}
