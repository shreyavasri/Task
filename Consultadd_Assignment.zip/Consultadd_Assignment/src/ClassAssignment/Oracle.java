package ClassAssignment;

public class Oracle extends AbDatabase {

	@Override
	public void connection() {
		// TODO Auto-generated method stub
		System.out.println("This is connection method of Oracle Class");

	}

	@Override
	public void openDB() {
		// TODO Auto-generated method stub
		System.out.println("This is Open DB method of Oracle Class");

	}

	@Override
	public void closeDB() {
		// TODO Auto-generated method stub
		System.out.println("This is close DB method of Oracle Class");

	}

	public void saveSession() {
		System.out.println("Session is saved : Oracle");	
	}
}
