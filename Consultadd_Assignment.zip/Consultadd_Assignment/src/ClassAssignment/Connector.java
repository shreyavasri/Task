package ClassAssignment;

public  abstract class Connector  {
	
	public abstract void openconnection();
	public void display(){
		System.out.println("This is connector class");
	}

}
