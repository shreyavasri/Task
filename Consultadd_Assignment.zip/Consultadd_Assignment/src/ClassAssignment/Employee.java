package ClassAssignment;

public class Employee {
	String name , year , address;
	int salary;
	
	public Employee(String name, String year, String address, int salary) {
		super();
		this.name = name;
		this.year = year;
		this.address = address;
		this.salary = salary;
	}
	
	@Override
	public String toString() {
	String result = "Name is : "+name+" Year is: "+year+" address is: "+address+" salary : "+salary;	
		
		return result;
	}
	
	public static void main(String[] args) {
	
		Employee emp = new Employee("shreya","1995","Noida",100);
		 
		Employee emp1 = new Employee("Robert","1993","Delhi",200);
       
        Employee emp2 = new Employee("sam","1994","Goa",300);
		 
        Employee emp3 = new Employee("John","1997","Delhi",400);
        
        System.out.println(emp);
        System.out.println(emp1);
        System.out.println(emp2);
        System.out.println(emp3);
	}

}
