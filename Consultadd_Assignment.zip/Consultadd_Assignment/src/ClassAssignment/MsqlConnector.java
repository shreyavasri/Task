package ClassAssignment;

public class MsqlConnector extends Connector {

	@Override
	public void openconnection() {
		System.out.println("Abstract implementaion MySQL connector");
	}
	
	public void displayMsql() {
		System.out.println("Msql");
	}
	

}
