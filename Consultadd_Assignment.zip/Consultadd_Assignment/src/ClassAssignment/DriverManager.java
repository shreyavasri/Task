package ClassAssignment;


public class DriverManager {
	
	public void displayInfo(Connector con) {
		if(con instanceof OracleConnector) {
			con.openconnection();
			((OracleConnector) con).displayConnector();
		}
		else if(con instanceof MsqlConnector) {
			con.openconnection();
			((MsqlConnector) con).displayMsql();
		}
		else if(con instanceof MssqlConnector) {
			con.openconnection();
			((MssqlConnector) con).displayMssql();
		}	
			
	}

	public static void main(String[] args) {

		DriverManager dm = new DriverManager();
		/*Connector con;
		con = new OracleConnector();
		dm.displayInfo(con);
		con = new MsqlConnector();
		dm.displayInfo(con);
		con = new MssqlConnector();
		dm.displayInfo(con);*/
		
		try {
		Class<?> clas = Class.forName(args[0]);//what class I want to Load? (Loads the class into the memory)
		Object random = clas.getDeclaredConstructor().newInstance();//Asking for the constructor of the loaded class
		
		dm.displayInfo((Connector)random);
		
		}
		catch(Exception e) {
			System.out.println(e);
		}
	}

}
