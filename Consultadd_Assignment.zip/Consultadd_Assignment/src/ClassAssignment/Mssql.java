package ClassAssignment;

public class Mssql extends AbDatabase {

	@Override
	public void connection() {
		// TODO Auto-generated method stub
		System.out.println("This is connection method of MySSql Class");
	}

	@Override
	public void openDB() {
		// TODO Auto-generated method stub
		System.out.println("This is openDB method of MySSql Class");
	}

	@Override
	public void closeDB() {
		// TODO Auto-generated method stub
		System.out.println("This is closeDB method of MySSql Class");

	}
	public void createCache() {
		System.out.println("cache is created : Mssql");
	}

}
