package ClassAssignment;

public class DBManager {

	public void OpenDBConnection(IDatabase db) {
		db.openDB();
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		DBManager db = new DBManager();
		db.OpenDBConnection(new MySql());
		db.OpenDBConnection(new Oracle());
		db.OpenDBConnection(new Mssql());
		}

}
