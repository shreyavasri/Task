package ClassAssignment;

public final class myImmutableClass {
	
	private String name ;
	
	public myImmutableClass(String name){
		this.name = name;
	}
	
	public myImmutableClass ModifyObjectvalue(String name) {
		if(this.name.equals(name)) {
			return this;
		}
		else 
			return (new myImmutableClass(name));
	}
	
	

	public static void main(String[] args) {
		myImmutableClass im = new myImmutableClass("shreya");
		myImmutableClass im2 = im.ModifyObjectvalue("shreya");
		System.out.println(im);
		System.out.println(im2);
		
	
		
		
		

	}

}
