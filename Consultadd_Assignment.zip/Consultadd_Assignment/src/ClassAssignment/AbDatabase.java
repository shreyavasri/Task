package ClassAssignment;

public abstract class AbDatabase implements IDatabase{
	

}
