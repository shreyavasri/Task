import java.util.Scanner;

//Write a program to print the value given by the user

public class UserInput {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		String s = scan.next();
		System.out.println(s);
		scan.close();
	}

}
