import java.util.Scanner;

/*Given an integer , perform the following conditional actions:
 If is odd, print NEW
 If is even and in the inclusive range of 2 to 5 , print OLD
 If is even and in the inclusive range of 6 to 30, print NEW
 If is even and greater than 30, print OLD
Complete the stub code provided in your editor to print whether or not is weird
*/
public class NewOld {

	public static void main(String[] args) {
	 Scanner scan = new Scanner(System.in);
	 int a = scan.nextInt();
	 if(a%2 == 1) {
		 System.out.println("NEW");
	 }
	 else if(a%2 == 0 && a>= 2 && a<=5) {
		 System.out.println("OLD");
	 }
	 else if(a%2 == 0 && a>= 6 && a<= 30) {
		 System.out.println("NEW");
	 }
	 else if(a%2 == 0 &&  a>30) {
		 System.out.println("OLD"); 
	 }
	}

}
