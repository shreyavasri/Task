

//Swap two numbers using third variable as result name and do the same task
//without using any third variable


public class Swap {

	public static void main(String[] args) {
		int a = 10 ;
		int b = 20 ;
		 a = a + b;
		 b = a - b ;
		 a = a - b ;
		 System.out.println(a);
		 System.out.println(b);
		

	}

}
