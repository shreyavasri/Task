import java.util.Arrays;
import java.util.Scanner;

/*Write a JAVA program that gives sum of all the values of array except the
highest and lowest values.
*/
public class SumOfArrays {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("How many values do you want to insert , value should be 3 or more?");
	    int	n = scan.nextInt();
		int[] array = new int[n];
		int final_sum =0;
	    for(int i =0 ; i < n;i++) {
			System.out.println("Enter the number ");
		    array[i]=scan.nextInt();
		}
		Arrays.sort(array);
		int sum = 0;
		for(int i=0;i<n;i++) {
			sum = sum + array[i];
		}
		
	    final_sum = sum - (array[0]+array[n-1]);
		System.out.println("sum is " +final_sum);
	}

}
