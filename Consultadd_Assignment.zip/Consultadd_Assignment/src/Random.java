import java.util.Scanner;

/*Write a JAVA program which takes character input from the user,
If the character is from r, a, n, d, o, m (consider both upper and lower
cases), then print FOUND.
Print NOT FOUND for all the other alphabets.
*/

public class Random {

	public static void main(String[] args) {
	char[] a = {'r','a','n','d','o','m'};
	boolean boo = false;
	Scanner scan = new Scanner(System.in);
	String enter = scan.next();
	enter = enter.toLowerCase();
	char c = enter.charAt(0);
	
	for(int i=0;i<a.length;i++) {
		if(c == (a[i])) {
			System.out.println("FOUND");
			boo = true;
			
		}
	}
	
	if(boo == false) {
		System.out.println("NOT FOUND");
	}
	scan.close();
	}

}
