import java.util.Scanner;

/*Write a program in JAVA to break and continue if the following cases occurs:
 If user enters a negative number just break the loop and print �It�s Over�
 If user enters a positive number just continue in the loop and print
�Good Going
*/


public class GoodGoing {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		int a = scan.nextInt();
		while(a > 0)
		{
			System.out.println("Good Going");
			a = scan.nextInt();
		}
		System.out.println("It's Over");
		
	}

}
