import java.util.Scanner;

/*
 * Create a class named 'Programming'. While creating an object of the class, if
nothing is passed to it, then the message "I love programming languages"
should be printed. If some String is passed to it, then in place of
"programming languages" the name of that String variable should be printed.
For example, while creating object if we pass "Java", then "I love Java" should
be printed. There can be more than one programming languages
 */
public class Programming {
	
	Programming(){
		System.out.println("I Love Programming Languages.");
	}
	Programming(String name){
		System.out.println("I Love "+name+".");
	}
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 Scanner scan = new Scanner(System.in);
		 System.out.println("Do you wish to enter any languages");
		 String yesno = scan.next();
		 if(yesno.toLowerCase().equals("no")) {
			 new Programming();
		 }
		 else {
		 while( yesno.toLowerCase().equals("yes")) {
			 
			 String name = scan.next();
			 new Programming(name);
			 
			 System.out.println("Do you wish to enter more?");
			 yesno = scan.next();
			 
			 
		 }
		 }
		 System.out.println("you are Done");
		 scan.close();
		
	}

}
