import java.util.Scanner;

/*Write a program to complete the task given below:
 Ask the user to enter any 2 numbers in between 1-10 and add both of
them to another variable call z.
 Use z for adding 30 into it and print the final result by using variable
results.*/


public class Add {

	
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter Two number between 1 to 10");
		int a = scan.nextInt();
		int b = scan.nextInt();
		int z = a + b + 30;
		System.out.println(z);
		scan.close();

	}

}
