import java.util.Scanner;

/*Write a program in JAVA to perform the following operator based task:
 Ask user to choose the following option first:
 If User Enter 1 - Addition
 If User Enter 2 - Subtraction
 If User Enter 3 - Division
 If User Enter 4 - Multiplication
 If User Enter 5 - Average

 Ask user to enter the 2 numbers in a variable for first and second(first
and second are variable names) for the first 4 options mentioned above
and print the result.
Ask user to enter two more numbers as first1 and second2 for
calculating the average as soon as user choose an option 5.
At the end if the answer of any operation is Negative print a statement
saying �Oops option X(1/2/3/4/5/) is returning the negative number�
NOTE: At a time user can perform one action at a time
*/
public class chooseOperator {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter Two number between 1 to 10");
		float a = scan.nextFloat();
		float b = scan.nextFloat();
		System.out.println("Enter the operation you want to perfom");
		int operation = scan.nextInt();
		
		switch(operation) {
		case 1: float sum = a + b;
						if(sum<0) {
							System.out.println("Oops option 1 is returning the negative number");
									}
						else
				           System.out.println(sum);
						break;
		case 2: float diff = a - b;
					if(diff<0) {
						System.out.println("Oops option 2 is returning the negative number");
					}
					else
						System.out.println(diff);
					break;
		
		case 3: float div = a/b;
						if(div < 0) {
								System.out.println("Oops option 3 is returning the negative number");
								}
						else  
							System.out.println(div);
						break;
		case 4:	float prod = a*b ;		
					if(prod < 0) {
							System.out.println("Oops option 4 is returning the negative number");
								}
						else  
								System.out.println(prod);
					break;
		case 5:	System.out.println("Enter two more numbers for average");
				float a1 = scan.nextFloat();
				float a2 = scan.nextFloat();
				float average = (a + b + a1 + a2)/4;
						if(average < 0) {
							System.out.println("Oops option 5 is returning the negative number");
								}
						else  
								System.out.println(average);
						break;
		default :
			System.out.println("Wrong choice");

				}
		
		
		
		scan.close();
		
		

	}

}
