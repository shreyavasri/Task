import java.util.Scanner;

/*
 * Your task is to write a function that takes a string and return a new
string with all vowels removed.
For example, the string "This website is for All!" would become "Ths wbst s fr
LL!".
 */
public class VowelRemove {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		String line = scan.nextLine();
		for(int i = 0;i<line.length();i++) {
			
		if(line.charAt(i) == 'i' || line.charAt(i) == 'e' ||line.charAt(i) == 'o' || line.charAt(i) == 'u' ||line.charAt(i) == 'a')
				continue;
		
		System.out.print(line.charAt(i));
		
		}

	}

}
