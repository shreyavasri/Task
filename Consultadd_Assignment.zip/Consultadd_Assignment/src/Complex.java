import java.util.Scanner;

/*
 * Print the sum, difference and product of two complex numbers by creating a
class named 'Complex' with separate methods for each operation whose real
and imaginary parts are entered by user.
 */
public class Complex {
   int real1 ; 
   int imaginary1;
   int real2;
   int imaginary2;
   
   
   
   public Complex(int real1 , int imaginary1, int real2, int imaginary2) {
	   this.real1 = real1;
	   this.imaginary1 = imaginary1;
	   this.real2 = real2;
	   this.imaginary2 = imaginary2;
   }
   
   public void sum() {
	   int realSum = real1+real2;
	   int imaginarySum = imaginary1+imaginary2;

	   System.out.println("sum is : : "+realSum+"+"+imaginarySum+"i");
   }
   public void sub() {
	   int realSub = real1-real2;
	   int imaginarySub = imaginary1-imaginary2;
	   if(imaginary1 > imaginary2) {
	   System.out.println("subtraction is : : "+realSub+"+"+imaginarySub+"i");
	   }
	   else {
		   System.out.println("subtraction is : : "+realSub+""+imaginarySub+"i");
	   }
   }
   public void prod() {
	   int realprod = real1*real2;
	   int imaginaryprod = imaginary1*imaginary2;

	   System.out.println("Product is : : "+realprod+"+"+imaginaryprod+"i");
   }
   
   
   
	public static void main(String[] args) {
		Scanner Scan = new Scanner(System.in);
		System.out.println("Enter Real and imaginary of first number and then second number");
		Complex com = new Complex(Scan.nextInt(),Scan.nextInt(),Scan.nextInt(),Scan.nextInt());
		com.sum();
		com.sub();
		com.prod();
		Scan.close();

	}

}
