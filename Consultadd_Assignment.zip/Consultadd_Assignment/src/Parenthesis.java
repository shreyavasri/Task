import java.util.Scanner;

/*
 * Write a JAVA program that gives boolean values; true, if the string has
balanced braces and false, if the string has unbalanced braces:
For eg, => �(
{
{
)
}
[
}
]
(
)
� //output => true //can�t use stack
//valid parenthesis
{{( [ ) ] }}
=> �[})(� //output => false.

 */
public class Parenthesis {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		String word = scan.nextLine();
		char[] wor = word.toCharArray();
		int curlyOpen =0 ,curlyclose=0,curvedOpen=0,curvedClose=0,SquareOpen=0,SqaureClose=0;
		boolean valid = false;
		
		for(int i=0;i<word.length();i++) {
			if(word.charAt(i) == '{') {
				
				curlyOpen++;
			}
			else if(word.charAt(i) == '}') {
				curlyclose++;
			}
			else if(word.charAt(i) == '(') {
				curvedOpen++;
			}
			else if(word.charAt(i) == ')') {
				curvedClose++;
			}
			else if(word.charAt(i) == '[') {
				SquareOpen++;
			}
			else if(word.charAt(i) == ']') {
				SqaureClose++;
			}
			
		}
		
		if(curlyOpen == curlyclose && curvedOpen == curvedClose && SquareOpen == SqaureClose) {
			valid = true;
			System.out.println(valid);
			
		}
		else {
			System.out.println(valid);
		}
		

	}

}
