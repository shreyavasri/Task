/*
 * Create a class named 'Rectangle' with two data members- length and breadth
and a method to calculate the area which is 'length*breadth'. The class has
three constructors which are :
1 - having no parameter - values of both length and breadth are assigned zero.
2 - having two numbers as parameters - the two numbers are assigned as
length and breadth respectively.
3 - having one number as parameter - both length and breadth are assigned
that number.
8
Now, create objects of the 'Rectangle' class having none, one and two
parameters and print their areas.

 */
public class RectangleOverloading {
	int length;
	int breadth;
	RectangleOverloading(){
		length = 0 ;
		breadth = 0;
		area(0,0);
	}
	RectangleOverloading(int length , int breadth){
		this.length = length;
		this.breadth = breadth;
		area(length,breadth);
	}
	RectangleOverloading(int one){
		length = one;
		breadth = one;
		area(length,breadth);
	}
	
	public void area(int length , int breadth) {
		int area = length*breadth;
		System.out.println("area is : "+area);
	}
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		RectangleOverloading rc  = new RectangleOverloading();
		RectangleOverloading rc1 = new RectangleOverloading(10,20);
		RectangleOverloading rc2 = new RectangleOverloading(30);

	}

}
