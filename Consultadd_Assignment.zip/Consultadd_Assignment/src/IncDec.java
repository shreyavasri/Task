import java.util.Scanner;

/*Write a program that accepts three numbers from the user and prints
"INCREASING" if the numbers are in increasing order, "DECREASING" if the
numbers are in decreasing order, and "Neither increasing or decreasing
order" otherwise. FOR eg.
Input first number: 1524
Input second number: 2345
Input third number: 3321
Output :
INCREASING
*/



public class IncDec {

	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter three numbers");
		int n1 = scan.nextInt();
		int n2 = scan.nextInt();
		int n3 = scan.nextInt();
		
		if(n1 < n2 && n2 < n3 ) {
			System.out.println(" number are in increasing order");
		}
		
		else if(n1 > n2 && n2 > n3 ) {
			System.out.println(" number are in decreasing order");
		}
		
		else {
			System.out.println("Niether increasing or decreasing");	
		}
		
		
		
	}

}
