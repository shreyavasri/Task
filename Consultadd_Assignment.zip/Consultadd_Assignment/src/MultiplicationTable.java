import java.util.Scanner;

/*1. Write a simple program to print multiplication table of a certain number
taken from user,
For eg. 2 X 1 = 2
2 X 2 = 4
and so on
*/




public class MultiplicationTable {
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		int a = scan.nextInt();
		for(int i=1;i<=10;i++) {
			int prod = a*i;
			System.out.println(a+" X "+i+" = "+prod);
		}

	}

}
