import java.util.Scanner;

/*Write a program in which:
a. Take 10 values input from user using loop.
b. Print sum of all the numbers provided
c. Print the Average of those 10 values
*/


public class Average {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		int[] array = new int[10];
		float sum = 0;
		for(int i = 0; i <10;i++ ) {
			array[i]=scan.nextInt();
		}
		for(int i = 0;i<10;i++) {
			sum = sum+array[i];
		}
		float
		avg = sum/10;
		System.out.println(avg);
		
		
	}

}
