import java.util.HashSet;
import java.util.Scanner;

/*
 * Write a JAVA method to return a boolean true if the string doesn�t have
repeating letters and consecutive or non consecutive i.e. all the letters of the
string be unique (isogram) else false
 */


public class Unique {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		String word = scan.nextLine();
		boolean result = true;
		HashSet<Character> unique = new HashSet<Character>();
		
		for(int i=0;i<word.length();i++) {
			result = unique.add(word.charAt(i));
			if(result == false) {
				System.out.println("Not unique");
				break;
			}
		}
		if(result == true)
		{
			System.out.println("Unique");
		}
	}

}
