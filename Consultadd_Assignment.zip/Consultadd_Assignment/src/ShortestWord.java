import java.util.Arrays;
import java.util.Scanner;
import java.util.StringTokenizer;

/*Write a JAVA program that takes given String of words and return the length
of the shortest word.
*/

public class ShortestWord {

	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);
		String word = scan.nextLine();
		String[] s = word.split(" ");
		StringTokenizer token = new StringTokenizer(word," ");
		int count = token.countTokens();
		int[] si = new int[count];
		for(int i = 0;i<count;i++)
		{
		si[i] = s[i].length();
		}
		Arrays.sort(si);
		System.out.println(si[0]);
		}
}
