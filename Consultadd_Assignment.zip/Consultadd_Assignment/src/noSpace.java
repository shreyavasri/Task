import java.util.Scanner;

/*Write a JAVA method to remove all the spaces from the String and return the
resultant.*/
public class noSpace {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		String s = scan.nextLine();
			s = s.replaceAll("\\s","");	
		    System.out.println(s);
		

	}

}
