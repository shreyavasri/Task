import java.util.Scanner;

/*
 * Write a JAVA program that swaps the case of the alphabets of the string,
a. For eg, => �heLLo WOrLd� => �HEllO woRlD�
*/
public class SwapCase {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		String word = scan.nextLine();
		char letter;
		
		for(int i =0;i< word.length();i++) {
			letter = word.charAt(i);
			
			if(Character.isLowerCase(letter)) {
				System.out.print(Character.toUpperCase(letter));
				
			}
			else if(Character.isWhitespace(letter)) {
				System.out.print(letter);
			}
			else if(Character.isUpperCase(letter)) {
				System.out.print(Character.toLowerCase(letter));
				
			}
			
		}
		scan.close();
	}

}
