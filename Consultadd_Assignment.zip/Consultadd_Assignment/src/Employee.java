import java.util.Date;

/*
 * Write a program that would print the information (name, year of joining,
salary, address) of three employees by creating a class named 'Employee'. The
output should be as follows:
Name Year of joining Address
Robert 1994 64C- Walls Streat
Sam 2000 68D- Walls Streat
John 1999 26B- Walls Streat

 */
public class Employee {
	
	
	String name , year , address;
	int salary;
	
	public Employee(String name, String year, String address, int salary) {
		
		this.name = name;
		this.year = year;
		this.address = address;
		this.salary = salary;
	}
	
	public void display() {
		String format = "%1$-10s%2$-20s%3$-20s%4$-20s\n";
		System.out.format(format, name , year , address , salary);
	   }
	
	public static void main(String[] args) {
		String format = "%1$-10s%2$-20s%3$-20s%4$-20s\n";
		System.out.format(format,"Name" ,"Year of joining " ,"address" ,"Salary");
		
		Employee emp = new Employee("shreya","1995","Noida",100);
				 emp.display();
		Employee emp1 = new Employee("Robert","1993","Delhi",200);
		         emp1.display();
		Employee emp2 = new Employee("sam","1994","Goa",300);
		 		 emp2.display();
		Employee emp3 = new Employee("John","1997","Delhi",400);
		         emp3.display();
		         
	}


}
