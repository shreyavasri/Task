import java.util.Scanner;

/*
 * Write a JAVA program that takes one integer input n from the user, and
display all the so, print sum of n natural numbers.
 */


public class nNaturalNumber {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		int a = scan.nextInt();
		int sum=0;
		for(int i=0;i<=a;i++)
		{
			sum = sum+i;
		}
		System.out.println(sum);
		
	}

}
