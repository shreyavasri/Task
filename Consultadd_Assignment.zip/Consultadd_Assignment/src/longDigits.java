import java.util.Scanner;

/*
 * Write a JAVA program that takes long type input from user, and
a. Calculate and display the number of digits.
b. Calculate the sum of all the digits of the input.

 */
public class longDigits {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		long a = scan.nextLong();
		long sum = 0;
		String digits = Long.toString(a);
		int length = digits.length();
		System.out.println(length);
		
		for(int i = 0; i < length; i++) {
		long digit = a%10;
		sum = sum + digit;
		a = a/10;
		}
		System.out.println(sum);

	}

}
