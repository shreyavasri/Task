import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

/*
 * Write a function that will return the count of distinct case-insensitive
alphabetic characters and numeric digits that occur more than once in
the input string. The input string can be assumed to contain only
alphabets (both uppercase and lowercase) and numeric digits.
 */
public class Distinctchar {
	
	public void getOccurancre(String s) {
		
		Map<Character,Integer> map = new HashMap<Character,Integer>();
		
		for (int i = 0; i < s.length(); i++) {
		  char c = s.charAt(i);
		  
		  if (map.containsKey(c)) 
		  {
		    int cnt = map.get(c);
		    map.put(c, ++cnt);
		  }
		  else {
		          map.put(c, 1);
		       }
		}
		
		map.forEach((key, value) -> System.out.println(key + " : " + value));
		
	}
	
	public static void main(String[] args){
		
		Scanner scan = new Scanner(System.in);
	    Distinctchar ch = new Distinctchar();
	    System.out.println("Enter Your String");
		ch.getOccurancre(scan.next());
		scan.close();

	}

}
