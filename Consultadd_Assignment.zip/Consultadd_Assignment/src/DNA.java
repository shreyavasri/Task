import java.util.Scanner;

/*
 * Deoxyribonucleic acid (DNA) is a chemical found in the nucleus of cells
and carries the "instructions" for the development and functioning of
living organisms.
In DNA strings, symbols "A" and "T" are complements of each other, as "C" and
"G".
DnaStrand.makeComplement("ATTGC") // return "TAACG" (in the result the A is
replaced by T, also, C is replaced by G and vice versa.)
DnaStrand.makeComplement("GTAT") // return "CATA"
 */
public class DNA {
	String DNA;
	
	public void makeComplement(String DNA) {
		this.DNA = DNA ;
		
		for(int i=0;i<DNA.length();i++) {
			if(DNA.charAt(i)== 'A')	{
				System.out.print("T");
			}
			else if(DNA.charAt(i)== 'T') {
				System.out.print("A");
			}
			else if(DNA.charAt(i)== 'C') {
				System.out.print("G");
			}
            else if(DNA.charAt(i)== 'G') {
            	System.out.print("C");
			}
			
			
		}
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter your DNA");
		DNA DnaStrand = new DNA();
		DnaStrand.makeComplement(scan.next());
		scan.close();
		
	}

}
