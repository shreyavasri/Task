package com.myMiniJavaProjects;

public class CustomException extends RuntimeException{
	
public CustomException() {
	super("Title of book must have four digits");
}	

}

 