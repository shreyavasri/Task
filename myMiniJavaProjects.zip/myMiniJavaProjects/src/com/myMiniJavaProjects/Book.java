package com.myMiniJavaProjects;

import java.util.ArrayList;
import java.util.List;

public class Book {
	private int bookno;
	private String title;
	private String author;
	private float price;
	private String category;
	private static int bookcount;
	static {
		bookcount = 0;
	}
	
	public Book() {}
	
	public Book(int bookno,String title,String author,float price) {
	String temp = Integer.toString(bookno);
	int count = temp.length();
	
		
		if(count < 4) {
			throw new CustomException();
		}
		else {
			
		this.bookno = bookno;
		}
		if(price < 0 && price> 50000) {
			throw new PriceCheck();
		}
		else {
		this.title = title;
		
		}
		this.author = author;
		this.price = price;
		bookcount++;
	}
	
	public String toString() {
		return bookno +" "+title+" "+author+" "+price ;
	}
	
	public void setBookno(int bookno) {
		this.bookno = bookno;
	}

	public String getTitle() {
		return title;
	}
	
	public int getBookno() {
		return bookno;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public float getPrice() {
		return price;
	}

	public void setPrice(float price) {
		this.price = price;
	}
	
	public static int getBookCount() {
		return bookcount;
	}
	
	public void setCategory(String category) {
		this.category = category;
	
    }
	
	public String getCategory() {
		return category;
	}
}