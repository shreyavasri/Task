package com.myMiniJavaProjects;

public class EngineeringBook extends Book {
	public static void main(String args[]) {
		 EngineeringBook Ebk = new  EngineeringBook();
		 Ebk.setCategory("Engineering");
		 System.out.println(Ebk.getCategory());
	}

}
