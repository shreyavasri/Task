package com.myMiniJavaProjects;

public class BookNotFoundException extends RuntimeException {
	
	public BookNotFoundException() {
	super("Book does not exist");
	}

}
