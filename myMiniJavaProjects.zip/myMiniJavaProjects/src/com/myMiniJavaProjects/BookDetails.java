package com.myMiniJavaProjects;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;

public class BookDetails {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	   // Book book = new Book();
		ArrayList al = new ArrayList();
	    Scanner scan = new Scanner(System.in);
	    Book[] bookC = new Book[3];
	    for(int i=0;i<3;i++) {
	    	bookC[i] = new Book(scan.nextInt(),scan.next(),scan.next(),scan.nextFloat());
	    	   System.out.println(bookC[i]);
	    	   al.add(bookC[i].getBookno());
	    }
	    
	    System.out.println(Book.getBookCount());
	    System.out.println("Enter the book number for the book you want to search ::"); 
	    int temp = scan.nextInt();	    
	    Iterator itr = al.iterator();
	    
	    while(itr.hasNext()) {
	    	if(itr.next().equals(temp)) 
	    	{
	    		for(int i =0 ; i < 3 ; i++) 
	    		{
	    			if(bookC[i].getBookno() == temp) 
	    			{
	    				System.out.println(bookC[i]);
	    			}
	    			
	    	}
	    	}	
	    	else 
	    	{
	    		throw new BookNotFoundException();	
	    	}
	    	
	    	break;
	    	
	    	
	    }
	    scan.close();
	    
	
	}

}
