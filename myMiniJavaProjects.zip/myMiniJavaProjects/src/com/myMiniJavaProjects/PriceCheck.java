package com.myMiniJavaProjects;

public class PriceCheck extends RuntimeException {
	
	public PriceCheck() {
	super("price must be in range 1 to 50,000");
	}

}
