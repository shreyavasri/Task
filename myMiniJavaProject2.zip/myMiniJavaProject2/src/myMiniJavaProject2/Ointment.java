package myMiniJavaProject2;

public class Ointment extends Medicine {
	public String displayLable() {
		return "for external use only";
	}
}
