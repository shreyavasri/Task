package myMiniJavaProject2;

import java.util.Date;

public abstract class Medicine {
	int price;
	Date ExpiryDate;
	public String getDetails() {
		return price +""+ExpiryDate;
	}
public abstract String displayLable();
}
