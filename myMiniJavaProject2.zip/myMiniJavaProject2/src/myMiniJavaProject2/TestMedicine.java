package myMiniJavaProject2;

public class TestMedicine {

	public static void main(String[] args) {
		Medicine[] medicine = new Medicine[5];
		for(int i=0;i<5;i++) {
			double randomDouble = Math.random();
			randomDouble = randomDouble * 3 + 1;
			int randomInt = (int) randomDouble;
			if(randomInt == 1) {
				medicine[i] = new Tablet();
			}
			if(randomInt == 2) {
				medicine[i] = new Syrup();
			}
			if(randomInt == 3) {
				medicine[i] = new Ointment();
				
			}
		System.out.println(medicine[i].displayLable());
		}

	}

}
