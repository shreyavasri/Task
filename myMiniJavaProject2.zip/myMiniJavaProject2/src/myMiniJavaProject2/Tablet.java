package myMiniJavaProject2;

public class Tablet extends Medicine {
	public String displayLable() {
		return " take as per prescription";
	}

}
