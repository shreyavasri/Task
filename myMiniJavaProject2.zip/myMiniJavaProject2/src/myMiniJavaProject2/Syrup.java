package myMiniJavaProject2;

public class Syrup extends Medicine {
	public String displayLable() {
		return "store in cool and dry place";
	}

}
