package com.test;
import com.shape.*;

public class testClass {

	public static void main(String[] args) {
		Square square = new Square();
		square.side = 10;
		square.calcarea();
		square.calcperi();
		
		Rectangle rec = new Rectangle();
		rec.length = 10;
		rec.breadth = 20;
		rec.calcarea();
		rec.calcperi();
		

	}

}
