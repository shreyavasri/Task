package com.shape;

public class Square implements Polygon {
	public float side;
	public void calcarea() {
		float area = side*side;
		System.out.println(area);
	}
	public void calcperi(){
		float peri = 4*side;
		System.out.println(peri);
	}

}
