package com.shape;

public interface Polygon {
	void calcarea();
	void calcperi();

}
