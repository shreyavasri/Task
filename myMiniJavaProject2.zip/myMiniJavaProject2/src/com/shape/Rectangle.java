package com.shape;

public class Rectangle implements Polygon{
	public float length;
	public float breadth;
	public void calcarea() {
		float area = length*breadth;
		System.out.println(area);
	}
	public void calcperi(){
		float peri = 2*(length+breadth);
		System.out.println(peri);
	}
}
